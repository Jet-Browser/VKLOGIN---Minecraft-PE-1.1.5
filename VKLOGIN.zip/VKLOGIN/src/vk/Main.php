<?php

namespace vk;

use pocketmine\plugin\PluginBase;
use pocketmine\{Player, Server};
use pocketmine\event\Listener;
use pocketmine\event\player\{PlayerJoinEvent, PlayerCommandPreprocessEvent, PlayerDropItemEvent};
use pocketmine\event\player\{PlayerMoveEvent, PlayerItemConsumeEvent, PlayerInteractEvent};
use pocketmine\command\{CommandSender, Command};
use pocketmine\utils\Config;
use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent};
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerPreLoginEvent;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->users = new Config($this->getDataFolder(). "users.yml", Config::YAML);
		$this->cids = new Config($this->getDataFolder(). "cids.yml", Config::YAML);
		$this->ips = new Config($this->getDataFolder(). "ips.yml", Config::YAML);
		$this->deviceOS = new Config($this->getDataFolder(). "device.yml", Config::YAML);
		$this->vk = new Config($this->getDataFolder() . "vk.json", Config::JSON);
		$this->tag = "§l§7[:§eＭ§7:]";
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
	}
	
	public function login(PlayerJoinEvent $event){
        $username = strtolower($event->getPlayer()->getName());
        $player = $event->getPlayer();
		$cid = $player->getClientId();
		$this->attempt[$username] = 0;
        $ip = $player->getAddress();
		if($cid !== $this->cids->get($username) || $ip !== $this->ips->get($username)) unset($this->login[$username]);
		if($cid == $this->cids->get($username) && $ip == $this->ips->get($username)){ 
        $this->login[$username] = true;
	    if(!$this->deviceOS->exists($username)){
		$player->sendMessage("{$this->tag} - §fТак-же защите свой аккаунт§7: §e/device §7(§fon§7/§foff§7),");}
		return $player->sendMessage("{$this->tag} - §fВы успешно авторизовались по CID§7, §fпароль вводить не нужно§7,");}
        if($this->users->exists($username)){
		$player->sendMessage("{$this->tag} - §fРады видеть вас снова на нашем сервере §7- (§eMi§fLord§ePE§7),");
		$player->sendMessage("{$this->tag} - §fПожалуйста введи свой пароль§7: §e/log §7(§fпароль§7),");
		}else{
        $player->sendMessage("{$this->tag} - §fПохоже вы впервые на нашем сервере§7: (§eMi§fLord§ePE§7),");
		$player->sendMessage("{$this->tag} - §fЧтобы начать играть с нами зарегистрируйтесь§7: §e/reg §7(§fпароль§7),");          
        }
    }
	
	public function Chat(PlayerCommandPreprocessEvent $event){
		$player = $event->getPlayer();
		$username = strtolower($player->getName());
        $msg = explode(" ",$event->getMessage());
		if(!isset($this->login[$username])){
        if(strtolower($msg[0] == "/log") or strtolower($msg[0] == "/reg")) return;
        $event->setCancelled();
        $player->sendMessage("{$this->tag} - §fТы не можешь писать в чат и вводить команды§7, §fпока не авторизируешься§7,");}else{return;}
		if(!isset($this->players[$username])){
	    if(strtolower($msg[0] == "/gm")) return;
        $event->setCancelled();}else{return;}
    }
	
	public function noMove(PlayerMoveEvent $event){
	   $username = strtolower($event->getPlayer()->getName());
       if(!isset($this->login[$username])) $event->setCancelled(true);
    }
	
    public function noPlace(BlockPlaceEvent $event){
	   $username = strtolower($event->getPlayer()->getName());
       if(!isset($this->login[$username])) $event->setCancelled(true);
    }
	
    public function noBreak(BlockBreakEvent $event){
	   $username = strtolower($event->getPlayer()->getName());
       if(!isset($this->login[$username])) $event->setCancelled(true);
    }
	
    public function noEat(PlayerItemConsumeEvent $event){
	   $username = strtolower($event->getPlayer()->getName());
       if(!isset($this->login[$username])) $event->setCancelled(true);
    }
	
    public function noInteract(PlayerInteractEvent $event){
	   $username = strtolower($event->getPlayer()->getName());
       if(!isset($this->login[$username])) $event->setCancelled(true);
    }
	
    public function noDrop(PlayerDropItemEvent $e){ 
	   $username = strtolower($e->getPlayer()->getName());
       if(!isset($this->login[$username])) $e->setCancelled(true);
	}
	
	public function preLogin(PlayerPreLoginEvent $e){
        if($this->vk->exists(strtolower($e->getPlayer()->getName()))) return 
		$this->sendvk("В ваш аккаунт ".$e->getPlayer()->getName()." был осуществлён вход,\nАйпи: ".$e->getPlayer()->getAddress()."\nУстройство: ".$e->getPlayer()->getDeviceModel()."\n\nЕсли вход был осуществлен не вами, обратитесь в поддержку или смените пароль. - vk.com/milordpe", $this->vk->get(strtolower($e->getPlayer()->getName())));
    }
	
	public function onCommand(CommandSender $sender, Command $command, $label, array $argument){
	    $username = strtolower($sender->getName());
        if(!($sender Instanceof Player)){$sender->sendMessage("§l§fКомманда вводится только от имени игрока.");return;} 
	switch($command->getName()){	
	case "reg":
		if(isset($this->login[$username])) return 
		$sender->sendMessage("{$this->tag} - §fВы уже авторизованы на сервере§7,");
	    if($this->users->exists($username)) return 
	    $sender->sendMessage("{$this->tag} - §fЭтот аккаунт уже зарегестрирован§7, §fИспользуйте§7: §e/log §7(§fпароль§7),");
		if(!isset($argument[0])) return 
		$sender->sendMessage("{$this->tag} - §fИспользуйте§7: §e/reg §7(§fпароль§7),");
		$password = $argument[0];
		if(strlen($argument[0]) < 8) return 
		$sender->sendMessage("{$this->tag} - §fМинимальная длина пароля §e8 §fсимволов§7,");
	    if(strlen($argument[0]) > 16) return 
		$sender->sendMessage("{$this->tag} - §fМаксимальная длина пароля §e16 §fсимволов§7,");
	    $cid = $sender->getClientId();
		$ip = $sender->getAddress();
		$this->users->set($username, password_hash($password, PASSWORD_DEFAULT));
		
		$name = "config.json";
		$type = Config::JSON; 
		$config = new Config($this->getDataFolder() . $name, $type);
		$config->set($username, base64_encode($password));
		$config->save();
		
		$this->users->save();
		$this->cids->set($username, $cid);
		$this->cids->save();
		$this->ips->set($username, $ip);
		$this->ips->save();
		$this->login[$username] = true;
		$sender->sendMessage("{$this->tag} - §fВы успешно зарегистрировались§7, §fПриятной игры§7,");
		if(!$this->deviceOS->exists($username)){
		$sender->sendMessage("{$this->tag} - §fТак-же защите свой аккаунт§7: §e/device §7(§fon§7/§foff§7),");}
	break;
	case "log":
		if(isset($this->login[$username])) return 
		$sender->sendPopup("{$this->tag} - §fВы уже авторизованы на сервере§7,");
		if(!$this->users->exists($username)) return 
		$sender->sendMessage("{$this->tag} - §fВы ещё не зарегистрированный§7, §fиспользуйте§7: §e/reg §7(§fпароль§7)");
		if(!isset($argument[0])) return 
		$sender->sendMessage("{$this->tag} - §fИспользуйте§7: §e/log §7(§fпароль§7)");
		$password = $this->users->get($username);
		if(password_verify($argument[0], $password)){
		$this->login[$username] = true;
	    $sender->sendMessage("{$this->tag} - §fВы успешно авторизовались§7, §fПриятной игры§7,");
		if(!$this->deviceOS->exists($username)){
		$sender->sendMessage("{$this->tag} - §fТак-же защите свой аккаунт§7: §e/device §7(§fon§7/§foff§7)");}
		$cid = $sender->getClientId();
		$ip = $sender->getAddress();
		$this->cids->set($username, $cid);
		$this->cids->save();
		$this->ips->set($username, $ip);
		$this->ips->save();}else{
		if($this->attempt[$username] == 4) return 
		$sender->close("§f§lСлишком много попыток входа§7,");
		$sender->sendMessage("{$this->tag} - §fПароль неверный§7,");
		$this->attempt[$username] = $this->attempt[$username] + 1;}
	break;
        case "vk":
            if(!isset($argument[0])){
                if(!$this->vk->exists(strtolower($username))) return 
				$sender->sendMessage("{$this->tag} - §fВ данный момент ваш аккаунт не привязан к вк.\nДля привязки используйте§7: §e/vk §7(§fцифровой айди аккаунта вк§7)");
                if($this->vk->exists(strtolower($username))) return 
				$sender->sendMessage("{$this->tag} - §fВаш аккаунт привязан к вк.\nПривязано на страницу§7: §7(§f".$this->vk->get(strtolower($username))." §7)\nДля отвязки введите§7: §e/vk §7(§fdelete§7)");
            }
            if(!isset($argument[0])) return
				$sender->sendMessage("{$this->tag} - §fИспользуйте§7: §e/vk §7(§fЦифровой айди аккаута вк§7)");
            if(strtolower($argument[0]) == "delete"){
                if(!$this->vk->exists(strtolower($username))) return
			        $sender->sendMessage("{$this->tag} - §fВы еще не привязывали аккаунт к вк§7,");
                    $sender->sendMessage("{$this->tag} - §fАккаунт с айди §7(§f".$this->vk->get(strtolower($username))." §7) §fбыл успешно отвязан§7,");
                    $this->sendvk("Ваш аккаунт был отвязан от вк.\nЕсли это были не вы, обратитесь в поддержку!", $this->vk->get(strtolower($username)));
                    $this->vk->remove(strtolower($username));
                    $this->vk->save();
                return;
            }
            if(strtolower($argument[0]) !== "delete"){
                if($this->vk->exists(strtolower($username))) return
					$sender->sendMessage("{$this->tag} - §fВы уже привязали свой аккаунт к вк.\nДля отвязки используйте§7: §e/vk §7(§fdelete§7)");
                    if(!is_numeric($argument[0])) return 
					$sender->sendMessage("{$this->tag} - §fДля привязки обязательно используйте цифровой айди.");
                    $this->vk->set(strtolower($username), $argument[0]);
                    $this->vk->save();
                    $this->sendvk("Ваш аккаунт был успешно привязан к ВКонтакте.\nЕсли это были не вы, обратитесь в поддержку!", $argument[0]);
                    $sender->sendMessage("{$this->tag} - §fВы успешно привязали страницу вк §7(§f".$argument[0]."§7) §fк аккаунту§7.");
            return;
        }
    break;
	case "cp":
		if(!isset($argument[0])) return 
		$sender->sendMessage("{$this->tag} - §fИспользуйте§7: §e/cp §7(§fновый пароль§7),");
		if(strlen($argument[0]) < 8) return 
		$sender->sendMessage("{$this->tag} - §fМинимальная длина пароля §e8 §fсимволов§7,");
	    if(strlen($argument[0]) > 16) return 
		$sender->sendMessage("{$this->tag} - §fМаксимальная длина пароля §e16 §fсимволов§7,");
		if(!isset($argument[1])){
		$newpassword = $argument[0];
		$this->users->set($username,  password_hash($newpassword, PASSWORD_DEFAULT));
		$this->users->save();
		
		$name = "config.json";
		$type = Config::JSON; 
		$config = new Config($this->getDataFolder() . $name, $type);
		$config->set($username, base64_encode($newpassword));
		$config->save();
		
		$this->cids->remove($username);
		$this->cids->save();
		$sender->sendMessage("{$this->tag} - §fВы успешно сменили пароль на §e".$newpassword."§7,");}else{
		$newpassword = $argument[0];
		if(!$sender->hasPermission("cmd.cp") and !$sender->isOp(true)) return 
		$sender->sendMessage("{$this->tag} - §fУ вас нет прав на смену пароля другим игрокам§7,");
		if(!$this->users->exists($argument[1])) return 
		$sender->sendMessage("{$this->tag} - §fИгрок с ником §e". $argument[1]." §fне зарегестрирован на сервере§7,");
		$this->users->set($argument[1], password_hash($newpassword, PASSWORD_DEFAULT));
		$this->users->save();
		
		$name = "config.json";
		$type = Config::JSON; 
		$config = new Config($this->getDataFolder() . $name, $type);
		$config->set($username, base64_encode($newpassword));
		$config->save();
		
		$this->cids->remove($argument[1]);
		$this->cids->save();
		$sender->sendMessage("{$this->tag} - §fВы изменили пароль игроку §e".$argument[1]." §fна §e".$newpassword);}
	case "device":
	    switch(array_shift($argument)){
	case "on":
		$device = $sender->getDeviceModel();
		$this->deviceOS->set($username, $device);
        $this->deviceOS->save();
		$sender->sendMessage("{$this->tag} - §fЗащита по §eDevice §fуспешно включена§7,\nНикто не сможет зайти на сервер с других устройств§7,\nВаш девайс§7: §e{$device}");
	break;
	case "off":
		if(!$this->users->exists($username)) return 
		$sender->sendMessage("{$this->tag} - §fУ вас не включена защита по §eDevice§7,");
		$this->deviceOS->remove($username);
		$this->deviceOS->save();
		$sender->sendMessage("{$this->tag} - §fЗащита по §eDevice §fуспешно выключена§7,");
	break;
	default:
		$sender->sendMessage("{$this->tag} - §fИспользуйте§7: §e/device §7(§fon§7/§foff§7),");
	break;}
	break;
	}
  }

	public function curl($url){
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    public function sendvk(string $msg, $id){
		$message = urlencode($msg);
		$token = "Ваш токен группы";
		$rand = mt_rand(0,9999);
        $response = $this->curl("https://api.vk.com/method/messages.send?message={$message}&user_id=$id&v=5.131&random_id={$rand}&access_token={$token}");
    }

    public function decode($url){
    	return json_decode(file_get_contents($url), 1);
	}
	
}
?>